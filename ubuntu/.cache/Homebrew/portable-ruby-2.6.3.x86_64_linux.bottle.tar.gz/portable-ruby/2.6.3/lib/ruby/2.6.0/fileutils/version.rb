# frozen_string_literal: true

module FileUtils
  VERSION = "1.1.0"
end
