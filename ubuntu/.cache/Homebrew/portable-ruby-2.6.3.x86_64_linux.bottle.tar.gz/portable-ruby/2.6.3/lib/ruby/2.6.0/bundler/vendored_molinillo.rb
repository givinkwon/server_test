# frozen_string_literal: true

module Bundler; end
require "bundler/vendor/molinillo/lib/molinillo"
